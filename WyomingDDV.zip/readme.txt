 

 
 
 GRID PIG 
 

 

   GRID PIG   
   Updated  Version 2.3, Dec 27 2001  
 Please report any problems to Trent Hare ( thare@usgs.gov )
 USGS  - Flagstaff, AZ 
  PIGWAD  Planetary online mapping page:  http://webgis.wr.usgs.gov  
  Online Help :  http://webgis.wr.usgs.gov/gridpig.htm  
 I would like to thank the many ArcView coders out there which many of these
routines were written by. When found, I have tried to squash any bugs. 
  Use this extension to:  This extension performs a variety of tasks that
include correcting some minor registration problems in the grid to image routines,
help with clipping, mosaic, set
to null, statistics. The extension requires Spatial Analyst. The image conversion
functions are only supported on a Microsoft Windows platform. 
  Install:  Download the .zip file and unzip it. Copy or move the
GridPig.avx and britecon.avx files to your ArcView's EXT32 directory. For
Window's users copy or move the g2i.dll file to ArcView's bin32 directory
(thanks to K. R. McVay). In
ArcView, open the Extensions menu and activate the Grid Pig extension. This will
add the Brightness and Contrast Editor button, the Move Theme button, and the
Grid Pig menu options to the View interface and the Continuous Color Legend tool
in the Layout interface. GridPig also updates the hillshade routine to give the
user a Z factor option. 
  Note:  Many Grid Pig tools will not activate until you add a grid to
your view. 
  Functions that the Grid Pig menu contains are:  
 
   Smooth Color Ramp (any legend - raster or vector) 
   Clip Grid with Graphic 
   Extract Grid from a Graphic 
   Clip Grid with Polygon 
   Grid Resample 
   Grid Statistics 
   Grid Truncate 
   Set Grid Value(s) to NULL 
   Grid Shift 
   Grid Rotate 
   Grid Unsigned to Signed 
   Grid Cut/Fill Value (very slow) 
   Mosaic Grids 
   Merge Grids 
   Convert Grid to Image (4 options: legend colors, with hillshade, single 8
    bit, or 3 grids to an RGB image)
     
       Updated code to allow floating point grids to RGB image conversion from J. Bissonnette 
     
   
   Batch Raster to Vector Point 
   Grid Value to a Point 
   Grid Values to a Line 
 
  Routine Descriptions  
 
     Smooth Color Ramp :  This function
    allows you to smooth the color scale. It will give a smoother color ramp
    when using many intervals. This should work on any legend - raster or
    vector. This routine also comes with a legend creator for layouts. It adds
    the min and max values. You will need to add the rest. 
    Clipping Routines: 
     
         Clip with a Graphic  : This function
        allows you to clip a portion of the grid by using a graphic such as a
        polygon or rectangle. It will clip to the extent of the graphic. The new clipped
        grid will be added to the view window. 
         Extract Grid with Graphic  : This
        function is similar to Clip with a Graphic, however, the area not
        clipped will be set to null. The new clip will be added to the view
        window. Use this when you want an irregular (none rectangular) clip. 
         Clip Grid with Polygon  : In order
        to operate this function, a polygon theme must be in the view window.
        This function will clip the extent of the polygon graphic and add it to
        the view. 
     
   
    Grid Routines 
     
         Grid Resample  : Resampling is the
        process of determining new values for cells in an output raster that
        result from applying a geometric transformation to an input raster
        dataset. There are three choices for resampling (1) nearest neighbor,
        (2) bilinear interpolation, (3) cubic convolution. Nearest neighbor
        determines the location of the closest cell center on the input raster
        and assigns the value of that cell to the cell on the output raster.
        Bilinear interpolation calculates the value for an output pixel from the
        values of the four nearest pixels in the input image based on the
        weighted distance to these pixels. Cubic convolution is similar to
        bilinear interpolation except the weighted average is calculated from
        the 16 nearest input cell centers and their values. 
         Grid Statistics  : Gives you the
        statistics of your grid. 
         Grid Truncate  : This function takes
        the values of the grid output and truncates to whole number (floating
        point to integer). 
         Set Grid Value(s) to NULL  : Allows
        you to select grid value(s) and set them to null. The value choices are:
        single value, less than or equal to, and greater than or equal to. 
         Grid Shift  : Will shift the X and Y
        coordinates of the raster dataset by a specified offset. 
         Grid Rotate  : Rotates the raster
        dataset by a specified amount. 
         Grid Unsigned to Signed  : ArcView
        does not recognize signed 16 bit files (images with negative values).
        Thus when an image is converted to a grid the negative values become
        large positive values. This tool will convert the values back to the
        correct negative value. 
     
   
    Grid Mosaics: Combine several spatially adjacent raster datasets into a
    single, larger dataset. 
     
         Mosaic Grids  : Smoothes the
        transition between the adjacent raster datasets in the overlapping
        areas. 
         Merge Grids  : The cell is assigned
        to the last input value from the series of input raster datasets. 
     
   
    Grid Conversions: 
     
         Convert Grid to Image  : Converts
        the grid to an image file with 4 options (legend colors, legend colors
        with hillshade, single 8 bit, or 3 grids to an RGB image). Output
        formats include TIF, JPG, BSQ, BIL, BIP. Now using code which allows
        conversion of float to rgb. 
         Batch Raster to Vector Point  :
        Converts each cell of the input raster to a point in the output dataset.
        Each point will be position at the center of the the cell that it
        represents. 
     
   
     Grid Value to a Point  : add X,Y and
    Grid value to a point theme. 
     Grid Values to a Line  : add X,Y and Grid
    value to the start and end points of a line theme. 
 

 

 